from setuptools import setup

setup(
    name='letter_classifier',
    version='0.1',
    scripts=['predictor.py'])